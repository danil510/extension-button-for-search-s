chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
});

chrome.tabs.onActivated.addListener(function(activeInfo) {
  chrome.tabs.get(activeInfo.tabId, function(tab) {
  });
});

