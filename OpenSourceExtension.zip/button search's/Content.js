// Создаем кнопку
const button = document.createElement('button');
button.textContent = 'Кнопка';
button.style.position = 'fixed';
button.style.zIndex = '16';
button.style.top = '59%';
button.style.left = '74%';
button.style.transform = 'translate(-50%, -50%)';

// Добавляем кнопку на страницу
document.body.appendChild(button);

// Get the DuckDuckGo search bar and the custom button
const searchBar = document.querySelector('input[name="q"]');

// Create a function that checks if the current URL includes '/about'
const checkUrl = () => {
  if (window.location.href.includes('/about')) {
    // Hide the custom button
    button.style.display = 'none';
  } else {
    // Show the custom button
    button.style.display = 'block';
  }
};

// Run the checkUrl function when the script is loaded
checkUrl();

// Add a MutationObserver to run the checkUrl function whenever the URL changes
const observer = new MutationObserver(() => {
  checkUrl();
});

observer.observe(document.body, { childList: true, subtree: true });

// Add a click event listener to the custom button
button.addEventListener('click', () => {
  // Copy the text input in the DuckDuckGo search bar
  const copiedText = searchBar.value;

  // Navigate to a different search engine (e.g. Google)
  const googleUrl = 'https://www.google.com/search?q=';
  const url = `${googleUrl}${copiedText}`;
  window.location.href = url;
});

window.addEventListener('scroll', function() {
  if (window.scrollY > 3) {
    // Скрываем кнопку, если прокрутка вниз
    button.style.display = 'none';
  } else {
    // Показываем кнопку, если прокрутка вверх
    button.style.display = 'block';
  }
});

if(window.location.href.includes('/?t=') || window.location.href.includes('/settings') || window.location.href.includes('/?q=')) {
  button.style.top = '6%';
button.style.left = '58%';
}

// Находим ссылку по классу
const link = document.querySelector('.header__logo-wrap');

// Функция, которая будет вызываться при клике на ссылку
function linkClick(event) {
  event.preventDefault(); 
  window.open("https://duckduckgo.com/", "_blank")
  button.style.top = '6%';
  button.style.left = '58%'
}

// Добавляем обработчик события для ссылки
link.addEventListener('click', linkClick);